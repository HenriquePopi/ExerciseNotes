import styled from "styled-components";
import React from "react";

export const ToggleVisibility = styled.button`
  width: 100%;
  background: rgb(53, 72, 125);
  background: linear-gradient(
    90deg,
    rgba(53, 72, 125, 1) 7%,
    rgba(108, 92, 122, 1) 32%,
    rgba(192, 109, 132, 1) 51%,
    rgba(246, 114, 112, 1) 64%
  );
  min-height: 45px;
  border: none;
  border: 1px solid rgba(108, 92, 122, 1);
  color: white;
  font-size: 25px;
  font-weight: bold;
  letter-spacing: 1.2px;
`;

export const Container = styled.div`
  width: 320px;
  max-height: 400px;
  overflow-x: hidden;
  overflow-y: scroll;
  margin: 0 auto;
  padding: 0 10px;
  display: block;
`;

import React from "react";
import {
  CalendarContainer,
  Day,
  PlaceHolder,
  DayName,
  Month,
  ToggleVisibility,
} from "./style";
import NoteModal from "../../Components/NoteModal";
import { NotesContext } from "../../NotesContext";

const months = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
];

const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];

const createListDays = (today) => {
  const daysInMonth = new Date(
    today.getFullYear(),
    today.getMonth() + 1,
    0
  ).getDate();
  const newListDays = [];
  for (let i = 1; i < daysInMonth + 1; i++) newListDays.push(i);

  return newListDays;
};

const thisDayInWeek = (day, today) => {
  return new Date(today.getFullYear(), today.getMonth(), day).getDay();
};

const Calendar = () => {
  const context = React.useContext(NotesContext);
  const today = new Date();
  const storage = window.localStorage;
  const listDays = createListDays(today);
  const monthDay1InWeekDay = thisDayInWeek(1, today);
  const [notesModalItens, setNotesModalItens] = React.useState([]);
  const [visible, setVisible] = React.useState(true);
  const showModal = (idsInThisDay) => {
    const notesInThisDay = idsInThisDay.map((id) =>
      JSON.parse(storage.getItem(id))
    );
    console.log(notesInThisDay);
    setNotesModalItens(notesInThisDay);
  };
  const handleToggleVisibility = () => {
    setVisible(!visible);
  };

  if (notesModalItens.length) {
    return (
      <>
        {notesModalItens.map((note, i) => (
          <NoteModal
            key={i}
            note={note}
            closeModal={() => setNotesModalItens([])}
          />
        ))}
        <ToggleVisibility onClick={() => setNotesModalItens([])}>
          Calendario +
        </ToggleVisibility>
      </>
    );
  }
  if (visible) {
    return (
      <>
        <CalendarContainer>
          <Month>{months[today.getMonth() + 1]}</Month>
          {weekDays.map((day, i) => (
            <DayName
              key={day}
              hasTraine={context.notesByDay[i].length}
              onClick={() => showModal(context.notesByDay[i])}
            >
              {day}
            </DayName>
          ))}
          <PlaceHolder spaceOfDays={monthDay1InWeekDay} />
          {listDays.map((day) => {
            return (
              <Day key={day} hasTraine={false}>
                {day}
              </Day>
            );
          })}
        </CalendarContainer>
        <ToggleVisibility onClick={handleToggleVisibility}>
          Calendario -
        </ToggleVisibility>
      </>
    );
  }

  return (
    <ToggleVisibility onClick={handleToggleVisibility}>
      Calendario +
    </ToggleVisibility>
  );
};

export default Calendar;

// import React from "react";
import styled from "styled-components";

export const Container = styled.div`
  width: 300px;
  margin: 0 auto;
  padding: 0 10px;
  flex: 1;
`;

export const CalendarContainer = styled(Container)`
  padding: 15px 0;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: center;
`;

export const Day = styled.span`
  width: calc(300px / 8 - 5px);
  margin-right: 5px;
  padding: 5px 0;
  margin-bottom: 10px;
  text-align: center;
  border: 1px solid rgba(246, 114, 127);
  color: rgba(246, 114, 127);
  font-weight: bold;
  border-radius: 3px;
  transition: 0.2s;
  cursor: pointer;
  position: relative;
  &:active {
    border-color: #35487d;
    background-color: rgba(246, 114, 127);
    color: white;
  }
  &:after {
    content: "";
    display: ${(props) => (props.hasTraine ? "block" : "none")};
    height: 6px;
    width: 6px;
    border-radius: 5px;
    background-color: rgba(246, 114, 127);
    border: 2px solid white;
    position: absolute;
    top: 0px;
    right: 0px;
  }
`;
export const DayName = styled(Day)`
  border: 1px solid #35487d;
  color: white;
  background: #35487d;
  margin-bottom: 30px;
  padding: 10px 0;
`;
export const PlaceHolder = styled.span`
  width: ${(props) => props.spaceOfDays * (300 / 7 - 3.4) + "px"};
`;

export const Month = styled.div`
  width: 100%;
  font-size: 25px;
  color: #35487d;
  border: 3px solid rgba(246, 114, 127);
  padding: 7px;
  text-align: center;
  font-weight: bold;
  border-radius: 10px;
  margin-bottom: 10px;
`;

export const ToggleVisibility = styled.button`
  width: 100%;
  background: rgb(53, 72, 125);
  background: linear-gradient(
    90deg,
    rgba(53, 72, 125, 1) 7%,
    rgba(108, 92, 122, 1) 32%,
    rgba(192, 109, 132, 1) 51%,
    rgba(246, 114, 112, 1) 64%
  );
  min-height: 45px;
  border: none;
  border: 1px solid rgba(108, 92, 122, 1);
  color: white;
  font-size: 25px;
  font-weight: bold;
  letter-spacing: 1.2px;
`;

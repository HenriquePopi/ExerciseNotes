// import React from "react";
import styled, { keyframes } from "styled-components";

const togleItem = keyframes`
  from {
    opacity: 1;
    display: block;
  }
  to {
    transform: translateY(-100px);
    display: none;
  }
`;

export const Container = styled.div`
  width: 300px;
  margin: 0 auto;
  padding: 0 10px;
  min-height: 200px;
  max-height: 300px;
  overflow-x: hidden;
  overflow-y: scroll;
`;
export const Title = styled.text`
  font-size: 20px;
  font-weight: bold;
`;

export const Input = styled.input`
  width: 80%;
  border-radius: 5px;
  padding: 5px;
  font-size: 16px;
  color: #35487d;
  border: 1px solid #f6727f;
  margin: 0 0 15px 0;
  &:focus {
    border: 2px solid #35487d;
    outline: none;
  }
`;
export const InputNotaName = styled(Input)`
  width: 97%;
  margin: 15px 0 20px 0;
  font-size: 18px;
`;

export const InputRepetitions = styled(Input)`
  width: 10%;
  font-size: 12px;
  text-align: center;
  margin-left: 3px;
`;
export const Row = styled.div`
  justify-content: space-between;
  display: flex;
  width: 300px;
  margin: 0 auto;
`;
export const Button = styled.button`
  height: 35px;
  display: block;
  background-color: #35487d;
  border-radius: 5px;
  font-size: 16px;
  color: #f6727f;
  padding: 3px;
  margin: 20px 0;
  transition: 0.3s;
  &:focus:active {
    box-shadow: 1px 1px #f6727f;
    border-color: #35487d;
    background-color: rgba(246, 114, 127);
    color: white;
  }
`;

export const ToggleVisibility = styled.button`
  width: 100%;
  background: rgb(53, 72, 125);
  background: linear-gradient(
    90deg,
    rgba(53, 72, 125, 1) 7%,
    rgba(108, 92, 122, 1) 32%,
    rgba(192, 109, 132, 1) 51%,
    rgba(246, 114, 112, 1) 64%
  );
  min-height: 45px;
  border: none;
  border: 1px solid rgba(108, 92, 122, 1);
  color: white;
  font-size: 25px;
  font-weight: bold;
  letter-spacing: 1.2px;
`;

export const Day = styled.span`
  width: calc(300px / 8 - 5px);
  margin-right: 8px;
  padding: 5px 3px;
  text-align: center;
  border: ${(props) =>
    props.selected ? "1px solid #35487d" : "1px solid rgba(246, 114, 127)"};
  color: ${(props) => (props.selected ? "#fff" : " rgba(246, 114, 127)")};
  background-color: ${(props) =>
    props.selected ? "rgba(246, 114, 127)" : "#fff"};
  font-weight: bold;
  border-radius: 3px;
  transition: 0.2s;
  cursor: pointer;
  &:active {
    border-color: #35487d;
    background-color: rgba(246, 114, 127);
    color: white;
  }
`;

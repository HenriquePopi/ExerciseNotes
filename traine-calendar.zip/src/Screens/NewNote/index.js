import React from "react";

import {
  Container,
  Input,
  InputNotaName,
  Button,
  Row,
  InputRepetitions,
  Day,
  ToggleVisibility,
} from "./style";

import { NotesContext } from "../../NotesContext";

const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"];

const NewNote = () => {
  const [visible, setVisible] = React.useState(false);
  const [notaName, setNotaName] = React.useState("");
  const [notaDay, setNotaDay] = React.useState([
    false,
    false,
    false,
    false,
    false,
    false,
    false,
  ]);
  const [notaRow, setNotaRow] = React.useState([{ exercise: "", reps: "" }]);
  const [showingNewRow, setShowingNewRow] = React.useState(false);
  const context = React.useContext(NotesContext);

  const handleSaveNote = () => {
    if (notaRow.length > 1) {
      const newNote = {
        name: notaName,
        note: notaRow,
        id: context.lastId,
        days: notaDay,
      };
      context.saveNewNote(newNote);
      setNotaRow([{ exercise: "", reps: "" }]);
      setNotaName("");
      setNotaDay([false, false, false, false, false, false, false]);
    }
  };

  const handleNotaRowChange = (target, key) => {
    const hasEmptyRows = (row) => row.exercise === "";
    notaRow[key].exercise = target.value;
    setNotaRow([...notaRow]);
    if (!showingNewRow && !notaRow.find(hasEmptyRows)) {
      setNotaRow([...notaRow, { exercise: "", reps: "" }]);
      setShowingNewRow(true);
    }
  };
  const handleDaySelection = (index) => {
    notaDay[index] = !notaDay[index];
    setNotaDay([...notaDay]);
  };

  const handleChangeRepetitions = (target, key) => {
    notaRow[key].reps = target.value;
    setNotaRow([...notaRow]);
  };
  const handleCancel = () => {
    setNotaRow([{ exercise: "", reps: "" }]);
    setNotaName("");
    setNotaDay([false, false, false, false, false, false, false]);
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };

  if (visible) {
    return (
      <>
        <ToggleVisibility onClick={toggleVisibility}>
          Nova Nota -
        </ToggleVisibility>
        <Container>
          <InputNotaName
            placeholder="Nome da Nota aqui"
            onChange={({ target }) => setNotaName(target.value)}
            value={notaName}
          />
          {notaRow.map((nota, k) => (
            <Row key={k}>
              <Input
                key={k}
                placeholder="Coloca um exercicio aqui!"
                onChange={({ target }) => handleNotaRowChange(target, k)}
                onBlur={() => setShowingNewRow(false)}
                value={nota.exercise}
              />
              <InputRepetitions
                onChange={({ target }) => handleChangeRepetitions(target, k)}
                placeholder="reps"
                value={nota.reps}
              />
            </Row>
          ))}

          {weekDays.map((day, i) => (
            <Day
              key={day}
              selected={notaDay[i]}
              onClick={() => handleDaySelection(i)}
            >
              {day}
            </Day>
          ))}
        </Container>
        <Row>
          <Button onClick={handleSaveNote}>Adicionar</Button>
          <Button onClick={handleCancel}>Cancelar</Button>
        </Row>
      </>
    );
  }

  return (
    <ToggleVisibility onClick={toggleVisibility}>Nova Nota +</ToggleVisibility>
  );
};

export default NewNote;
